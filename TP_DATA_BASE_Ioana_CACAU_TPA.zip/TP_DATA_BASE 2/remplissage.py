import sqlite3
import random

# Connexion à la base de données
conn = sqlite3.connect('logement.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

# Insertion d'une facture avec toutes les colonnes nécessaires
c.execute("""
    INSERT INTO Facture (id_logement, type_Facture, montant, valeur_consommation, date_facture, unite) 
    VALUES (1, 'eau', 120.3, 34, CURRENT_TIMESTAMP, 'litres')
""")
c.execute("""
    INSERT INTO Facture (id_logement, type_Facture, montant, valeur_consommation, date_facture, unite) 
    VALUES (1, 'électricité', 1209.3, 124, CURRENT_TIMESTAMP, 'kWh')
""")

# Génération de factures aléatoires
facts = []
for i in range(4):
    facts.append((1, 'eau', round(random.uniform(0, 10000), 2), round(random.uniform(0, 1000), 2), '2025-01-12', 'litres'))
    facts.append((1, 'électricité', round(random.uniform(0, 10000), 2), round(random.uniform(0, 1000), 2), '2025-01-12', 'kWh'))
c.executemany("""
    INSERT INTO Facture (id_logement, type_Facture, montant, valeur_consommation, date_facture, unite) 
    VALUES (?, ?, ?, ?, ?, ?)
""", facts)

# Insertion de plusieurs mesures dans la table Mesure
values = []
for i in range(3):
    values.append((1, round(random.uniform(-100, 100), 2)))  # Température par exemple
    values.append((2, round(random.uniform(0, 100), 2)))    # Luminosité par exemple
    values.append((3, random.choice([0, 1])))               # État binaire
    values.append((4, round(random.uniform(0, 100), 2)))    # Humidité par exemple
c.executemany('INSERT INTO Mesure (id_capteur, valeur) VALUES (?, ?)', values)

# Lecture des données dans la table Facture
c.execute('SELECT * FROM Facture')
factures = c.fetchall()
print("Données dans la table Facture:")
for Facture in factures:
    print(dict(Facture))

# Lecture des données dans la table Mesure
c.execute('SELECT * FROM Mesure')
mesures = c.fetchall()
print("\nDonnées dans la table Mesure:")
for Mesure in mesures:
    print(dict(Mesure))

# Fermeture de la connexion
conn.commit()
conn.close()
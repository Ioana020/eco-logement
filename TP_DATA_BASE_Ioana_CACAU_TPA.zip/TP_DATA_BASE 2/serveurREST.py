from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from collections import defaultdict
import sqlite3
from typing import List
import os
from fastapi import Form
from fastapi.responses import FileResponse

#temperature: 
import httpx

from fastapi.staticfiles import StaticFiles



app = FastAPI()
app.mount("/static", StaticFiles(directory="WEBSITE"), name="static")



#ouverture et initialisation de la base de données
def connexion_base():
    conn = sqlite3.connect('logement.db')
    conn.row_factory = sqlite3.Row
    return conn

# creer classes 
class Mesure(BaseModel):
    id_capteur: int
    valeur: float

class Facture(BaseModel):
    id_logement: int
    type_facture: str
    montant: float
    valeur_consommation: float

class Capteur(BaseModel):
    type_id: int
    reference_commerciale: str
    port_comm: str
    id_piece: int



# Sources
# Google Charts pour tous les graphiques utilisés
# ChatGPT (utilisé comme tutoriel notamment pour la partie HTML et CSS)
# J'ai utilisé ChatGPT pour améliorer le design des pages HTML et CSS, ainsi que pour corriger certaines erreurs. 
# Prompt utilisé : "mon code ... présente cette errreur ..., peux tu m'expliquer pourquoi et comment la corriger ?"




# # -------------------------GETs --------------------------- 

@app.get("/factures", response_model=List[dict])
async def get_factures():
    conn = connexion_base()
    c = conn.cursor()
    c.execute('SELECT * FROM Facture')
    factures = c.fetchall()
    conn.close()
    
    return [dict(facts) for facts in factures]

@app.get("/mesures")
async def get_mesures():
    conn = connexion_base()
    c = conn.cursor()
    c.execute("SELECT * FROM Mesure")
    mesures = c.fetchall()
    conn.close()
    
    return {"mesures": [dict(m) for m in mesures]}


# Aide : ChatGPT
# Prompt : "comment créer une route GET avec FastAPI pour intégrer un code HTML et afficher les données météo récupérées"
@app.get("/meteo", response_class=HTMLResponse)
async def get_meteo():
    async with httpx.AsyncClient() as client:
        response = await client.get(API_URL)

    if response.status_code != 200:
        return HTMLResponse(content="<h3>Erreur : Impossible de récupérer les données météo.</h3>", status_code=500)

    data = response.json()
    navbar = load_navbar()


    # Extraire les données actuelles
    current_weather = data.get("current_weather", {})
    temperature_current = current_weather.get("temperature")
    wind_speed_current = current_weather.get("windspeed")
    precipitation_current = current_weather.get("precipitation", 0)

    # Extraire les données journalières
    daily_max_temp = data.get("daily", {}).get("temperature_2m_max", [])
    daily_wind_speed_max = data.get("daily", {}).get("wind_speed_10m_max", [])


    # Construire le contenu HTML avec f-string
    html_content = f"""
<html>
  <head>
    <title>Météo</title>
    <link rel="stylesheet" href="/static/css/styles.css">
    <style>
      body {{
        font-family: Arial, sans-serif;
        padding: 20px;
      }}
      h2 {{
        text-align: center;
        color: #007BFF;
        font-size: 28px;
        font-weight: bold;
      }}
      p {{
        text-align: center;
        color: #333;
      }}
    </style>
  </head>
  <body>
    {navbar} <!-- Insertion de la navbar -->
    <h2>Météo Actuelle</h2>
    <p>Température actuelle : {temperature_current}°C</p>
    <p>Vitesse du vent actuelle : {wind_speed_current} km/h</p>
    <p>Précipitations actuelles : {precipitation_current} mm</p>
    <h2 style="color: red; font-size: 24px; font-weight: bold;">Prévisions des 5 prochains jours :</h2>
"""

    
    # Afficher les températures maximales et la vitesse du vent maximale
    for i in range(5):
        temp = daily_max_temp[i]
        wind_speed = daily_wind_speed_max[i]
        html_content += f"<p>Jour {i + 1} : Température : {temp}°C, Vitesse du vent max : {wind_speed} km/h</p>"

    html_content += "</ul>"

    return HTMLResponse(content=html_content)



# Prompt : "comment afficher les mesures dans une table html avec fastapi et les données?"
@app.get("/mesures/view", response_class=HTMLResponse)
async def view_mesures():
    navbar = load_navbar()

    conn = connexion_base()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT Mesure.id_capteur, Mesure.valeur, Mesure.date_insertion, Piece.nom AS piece_nom, TypeCapteur.nom AS type_nom
        FROM Mesure
        JOIN Capteur ON Mesure.id_capteur = Capteur.id
        JOIN Piece ON Capteur.id_piece = Piece.id
        JOIN TypeCapteur ON Capteur.type_id = TypeCapteur.id
        """
    )
    mesures = cursor.fetchall()
    conn.close()

    html_content = f"""
    <html>
      <head>
        <title>État des capteurs</title>
        <link rel="stylesheet" href="/static/css/styles.css">

        <style>
          table {{
            width: 80%;
            border-collapse: collapse;
            margin: 20px auto;
            font-family: Arial, sans-serif;
          }}
          th, td {{
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
          }}
          th {{
            background-color: #72a169;
            color: white;
          }}
          tr:nth-child(even) {{
            background-color: #f2f2f2;
          }}
          h1 {{
            text-align: center;
            color: #333;
            margin-top: 20px;
          }}
        </style>
      </head>
      <body>
        {navbar} <!-- Insertion de la navbar -->
        <h1>État des capteurs</h1>
        <table>
          <tr>
            <th>ID Capteur</th>
            <th>Type de Capteur</th>
            <th>Valeur Mesurée</th>
            <th>Pièce</th>
            <th>Date de Mesure</th>
          </tr>
    """

    for m in mesures:
        html_content += f"<tr><td>{m['id_capteur']}</td><td>{m['type_nom']}</td><td>{m['valeur']}</td><td>{m['piece_nom']}</td><td>{m['date_insertion']}</td></tr>"

    html_content += """
        </table>
      </body>
    </html>
    """
    return HTMLResponse(content=html_content)



# Prompt : "comment afficher un fichier html avec fastapi et file response pour la page d'accueil ?"
# pour la page d'acceuil 
@app.get("/", response_class=HTMLResponse)
async def homepage():
    return FileResponse("WEBSITE/index.html")
  


# Prompt : comment ajouter un navbar sur une page html crééé a partir d'un fichier python

@app.get("/home", response_class=HTMLResponse)
async def homepage():
    return FileResponse("WEBSITE/home.html")
  
# Prompt : "comment créer une page html avec fastapi pour afficher un formulaire de configuration en récupérant les données depuis une base de données ?"
# Prompts pour améliorer le design de la page


# pour la page home
@app.get("/configuration", response_class=HTMLResponse)
async def configuration_page():
    navbar = load_navbar()  

    conn = connexion_base()
    cursor = conn.cursor()

    cursor.execute("SELECT id, nom FROM Piece")
    pieces = cursor.fetchall()

    cursor.execute("SELECT id, nom FROM TypeCapteur")
    types_capteurs = cursor.fetchall()
    conn.close()

    dropdown_types = "<select id='type_id' name='type_id' class='form-control'>"
    for type_capteur in types_capteurs:
        dropdown_types += f"<option value='{type_capteur['id']}'>{type_capteur['nom']}</option>"
    dropdown_types += "</select>"

    dropdown_pieces = "<select id='id_piece' name='id_piece' class='form-control'>"
    for piece in pieces:
        dropdown_pieces += f"<option value='{piece['id']}'>{piece['nom']}</option>"
    dropdown_pieces += "</select>"

    html_content = f"""
    <html>
    <head>
        <title>Configuration</title>
        <link rel='stylesheet' href='/static/css/styles.css'>
        <style>
            body {{
                font-family: Arial, sans-serif;
                background-color: #f9f9f9;
                margin: 0;
                padding: 0;
            }}
            .container {{
                max-width: 800px;
                margin: 50px auto;
                padding: 20px;
                background-color: #ffffff;
                border-radius: 8px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }}
            h1 {{
                text-align: center;
                color: #333;
                margin-bottom: 20px;
            }}
            .form {{
                display: flex;
                flex-direction: column;
                gap: 15px;
            }}
            .form-group {{
                display: flex;
                flex-direction: column;
            }}
            .form-group label {{
                font-weight: bold;
                margin-bottom: 5px;
            }}
            .form-control {{
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 16px;
            }}
            .form-control:focus {{
                outline: none;
                border-color: #72a169;
                box-shadow: 0 0 5px rgba(114, 161, 105, 0.5);
            }}
            .btn {{
                background-color: #72a169;
                color: white;
                padding: 10px;
                border: none;
                border-radius: 4px;
                font-size: 18px;
                cursor: pointer;
                text-align: center;
            }}
            .btn:hover {{
                background-color: #5b8f57;
            }}
        </style>
    </head>
    <body>
        {navbar}
        <div class='container'>
            <h1>Ajouter un Capteur</h1>
            <form action='/add_capteur' method='post' class='form'>
                <div class='form-group'>
                    <label for='type_id'>Type de Capteur:</label>
                    {dropdown_types}
                </div>
                <div class='form-group'>
                    <label for='reference_commerciale'>Référence Commerciale:</label>
                    <input type='text' id='reference_commerciale' name='reference_commerciale' class='form-control' required>
                </div>
                <div class='form-group'>
                    <label for='port_comm'>Port de Communication:</label>
                    <input type='text' id='port_comm' name='port_comm' class='form-control' required>
                </div>
                <div class='form-group'>
                    <label for='id_piece'>Pièce:</label>
                    {dropdown_pieces}
                </div>
                <button type='submit' class='btn'>Ajouter</button>
            </form>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

# Source : ChatGPT et Google Charts
# Prompt : tu peux m'expliquer sous forme de tutoriel comment créer un graphique avec google charts en html, 
# et comment le connecter avec une base de données et fastapi pour afficher des données dynamiques ?

@app.get("/consommation/chart", response_class=HTMLResponse)
async def consommation_chart(adresse: str = None, scale: str = "Mois", type_facture: str = None):
    navbar = load_navbar() 

    conn = connexion_base()
    cursor = conn.cursor()

    cursor.execute("SELECT adresse FROM Logement")
    addresses = cursor.fetchall()

    cursor.execute("SELECT DISTINCT type_facture FROM Facture")
    type_factures = cursor.fetchall()

    query = """
        SELECT strftime('%Y-%m', date_facture) as period, SUM(valeur_consommation) as total, MAX(unite) as unit
        FROM Facture
        JOIN Logement ON Facture.id_logement = Logement.id
        WHERE 1=1
    """

    params = []
    if adresse:
        query += " AND Logement.adresse = ?"
        params.append(adresse)

    if type_facture:
        query += " AND Facture.type_facture = ?"
        params.append(type_facture)

    if scale == "Année":
        query = query.replace("strftime('%Y-%m', date_facture)", "strftime('%Y', date_facture)")

    query += " GROUP BY period ORDER BY period"

    cursor.execute(query, params)
    consommation_data = cursor.fetchall()
    conn.close()

    dropdown_adresse = "<select id='adresse' name='adresse' onchange='changeParams()' class='dropdown'>"
    dropdown_adresse += "<option value=''>Adresse</option>"
    for addr in addresses:
        selected = "selected" if addr[0] == adresse else ""
        dropdown_adresse += f"<option value='{addr[0]}' {selected}>{addr[0]}</option>"
    dropdown_adresse += "</select>"

    dropdown_scale = "<select id='scale' name='scale' onchange='changeParams()' class='dropdown'>"
    dropdown_scale += f"<option value='Mois' {'selected' if scale == 'Mois' else ''}>Mois</option>"
    dropdown_scale += f"<option value='Année' {'selected' if scale == 'Année' else ''}>Année</option>"
    dropdown_scale += "</select>"

    dropdown_type = "<select id='type_facture' name='type_facture' onchange='changeParams()' class='dropdown'>"
    dropdown_type += "<option value=''>"
    for tf in type_factures:
        selected = "selected" if tf[0] == type_facture else ""
        dropdown_type += f"<option value='{tf[0]}' {selected}>{tf[0]}</option>"
    dropdown_type += "</select>"

    chart_data = ""
    unit = ""
    for row in consommation_data:
        if row[1] is not None and "-" in row[0]:
            period = row[0].split("-")
            Année = int(period[0])
            Mois = int(period[1]) - 1  
            chart_data += f"[new Date({Année}, {Mois}), {row[1]}],"
            unit = row[2] if row[2] else ""
        elif row[1] is not None:
            Année = int(row[0])
            chart_data += f"[new Date({Année}, 0), {row[1]}],"
            unit = row[2] if row[2] else ""
        else:
            chart_data += f"[new Date(), 0],"

    html_content = f"""
    <html>
      <head>
        <title>Consommation</title>
        <link rel="stylesheet" href="/static/css/styles.css">
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
          google.charts.load('current', {{'packages':['corechart']}});
          google.charts.setOnLoadCallback(drawChart);

          function drawChart() {{
            var data = google.visualization.arrayToDataTable([
              ['Période', 'Consommation ({unit})'],
              {chart_data}
            ]);

            var options = {{
              title: 'Consommation par période ({unit})',
              hAxis: {{ title: 'Période', titleTextStyle: {{ color: '#333' }}, format: 'MMM yyyy' }},
              vAxis: {{ title: 'Consommation', minValue: 0 }},
              chartArea: {{ width: '80%', height: '70%' }},
              colors: ['#3366CC'],
              fontName: 'Arial',
              titleTextStyle: {{
                fontSize: 20,
                bold: true,
                color: '#444'
              }},
              legend: {{ position: 'bottom' }}
            }};

            var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
            chart.draw(data, options);
          }}

          function changeParams() {{
            const adresse = document.getElementById('adresse').value;
            const scale = document.getElementById('scale').value;
            const type_facture = document.getElementById('type_facture').value;
            window.location.href = `/consommation/chart?adresse=${{adresse}}&scale=${{scale}}&type_facture=${{type_facture}}`;
          }}
        </script>
        <style>
          body {{
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
          }}
          .container {{
            max-width: 90%;
            margin: 20px auto;
            padding: 20px;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
          }}
          h1 {{
            text-align: center;
            color: #333;
            margin-bottom: 20px;
          }}
          .dropdown {{
            width: 50%;
            padding: 10px;
            margin: 15px auto;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: block;
          }}
          .dropdown:focus {{
            outline: none;
            border-color: #72a169;
          }}
          #chart_div {{
            width: 100%;
            height: 500px;
            margin-top: 30px;
          }}
        </style>
      </head>
      <body>
        {navbar} <!-- Insertion de la navbar -->
        <div class="container">
          <h1>Consommation par Adresse</h1>
          <div>
            <label for="adresse">Adresse:</label>
            {dropdown_adresse}
          </div>
          <div>
            <label for="scale">Période:</label>
            {dropdown_scale}
          </div>
          <div>
            <label for="type_facture">Type de consommation</label>
            {dropdown_type}
          </div>
          <div id="chart_div"></div>
        </div>
      </body>
    </html>
    """
    return HTMLResponse(content=html_content)




@app.get("/sensors", response_class=HTMLResponse)
async def show_sensors():
    navbar = load_navbar()  
    
    conn = connexion_base()
    cursor = conn.cursor()

    query = """
        SELECT Capteur.id AS sensor_id, 
               TypeCapteur.nom AS sensor_type, 
               Capteur.reference_commerciale AS reference, 
               Capteur.port_comm AS port, 
               Piece.nom AS room
        FROM Capteur
        JOIN TypeCapteur ON Capteur.type_id = TypeCapteur.id
        JOIN Piece ON Capteur.id_piece = Piece.id
    """
    cursor.execute(query)
    sensors = cursor.fetchall()
    conn.close()

    html_content = f"""
    <html>
      <head>
        <title>Liste des Capteurs</title>
        <link rel="stylesheet" href="/static/css/styles.css"> <!-- Stilizare -->
        <style>
          table {{
              width: 80%;
              margin: 20px auto;
              border-collapse: collapse;
              text-align: left;
          }}
          th, td {{
              padding: 12px;
              border: 1px solid #ddd;
          }}
          th {{
              background-color: #72a169;
              color: white;
          }}
          tr:nth-child(even) {{
              background-color: #f2f2f2;
          }}
        </style>
      </head>
      <body>
        {navbar} <!-- Include navbar-ul -->
        <h1 style="text-align: center;">Liste des Capteurs</h1>
        <table>
          <tr>
            <th>ID</th>
            <th>Type de Capteur</th>
            <th>Référence Commerciale</th>
            <th>Port de Communication</th>
            <th>Pièce</th>
          </tr>
    """
    for sensor in sensors:
        html_content += f"""
          <tr>
            <td>{sensor['sensor_id']}</td>
            <td>{sensor['sensor_type']}</td>
            <td>{sensor['reference']}</td>
            <td>{sensor['port']}</td>
            <td>{sensor['room']}</td>
          </tr>
        """

    html_content += """
        </table>
      </body>
    </html>
    """
    return HTMLResponse(content=html_content)


@app.get("/factures/chart", response_class=HTMLResponse)
async def factures_chart():
    navbar = load_navbar()
    
    
    conn = connexion_base()
    cursor = conn.cursor()
    cursor.execute("SELECT Type_facture, SUM(Montant) as total FROM Facture GROUP BY Type_facture")
    facture_data = cursor.fetchall()
    conn.close()

    # Préparer les données pour Google Charts
    factures = ""
    for facts in facture_data:
        factures += f"['{facts['Type_facture']}', {facts['total']}],"

    # Code HTML avec Google Charts pour afficher le camembert
    html_content = f"""
    <html>
      <head>
      <link rel="stylesheet" href="/static/css/styles.css">
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
          google.charts.load('current', {{'packages':['corechart']}});
          google.charts.setOnLoadCallback(drawChart);
          

          function drawChart() {{
            var data = google.visualization.arrayToDataTable([
              ['Type de Facture', 'Montant'],
              {factures}
            ]);

            var options = {{  title: 'Factures par type',
                titleTextStyle: {{
                  color: 'black',         
                  fontSize: 24,           
                  bold: true,             
                  italic: false,        
                }},
                chartArea: {{
                  width: '80%',           
                  height: '70%',
                }},
              }};

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));
            chart.draw(data, options);
          }}
        </script>
        
        
  
  </script>
  
  
        
      </head>
      <body>
      {navbar} <!-- Insertion de la navbar -->
      
        <div id="piechart" style="width: 900px; height: 500px;"></div>
      </body>
    </html>
    """

    return HTMLResponse(content=html_content)

@app.get("/economies/comparison", response_class=HTMLResponse)
async def economies_comparison(adresse: str = None, scale: str = "Mois"):
    navbar = load_navbar()

    conn = connexion_base()
    cursor = conn.cursor()

    # récupérer la liste des adresses disponibles
    cursor.execute("SELECT DISTINCT adresse FROM Logement")
    addresses = cursor.fetchall()

    # requête pour obtenir les données des factures
    query = """
        SELECT 
            strftime('%Y-%m', date_facture) as period, 
            type_facture, 
            SUM(montant) as total_cost
        FROM Facture
        JOIN Logement ON Facture.id_logement = Logement.id
        WHERE 1=1
    """

    params = []

    if adresse:
        query += " AND Logement.adresse = ?"
        params.append(adresse)

    if scale == "Année":
        query = query.replace("strftime('%Y-%m', date_facture)", "strftime('%Y', date_facture)")

    query += " GROUP BY period, type_facture ORDER BY period"

    cursor.execute(query, params)
    data = cursor.fetchall()
    conn.close()

    # préparer les données pour Google Charts
    chart_data = "['Période',"
    type_factures = {}

    for row in data:
        type_facture = row['type_facture']
        if type_facture not in type_factures:
            type_factures[type_facture] = len(type_factures) + 1
            chart_data += f" '{type_facture}',"

    chart_data = chart_data[:-1] + "]"

    periods = {}

    for row in data:
        period = row['period']
        if period not in periods:
            periods[period] = [0] * len(type_factures)

        type_facture_index = type_factures[row['type_facture']] - 1
        periods[period][type_facture_index] = row['total_cost']

    for period, costs in periods.items():
        chart_data += f",['{period}', {', '.join(map(str, costs))}]"

    # construire le menu déroulant pour la sélection d'adresse
    dropdown_adresse = "<select id='adresse' name='adresse' onchange='changeAddress()'>"
    dropdown_adresse += "<option value=''>Toutes les adresses</option>"
    for addr in addresses:
        selected = "selected" if addr[0] == adresse else ""
        dropdown_adresse += f"<option value='{addr[0]}' {selected}>{addr[0]}</option>"
    dropdown_adresse += "</select>"

    html_content = f"""
    <html>
      <head>
        <title>Comparatif des Économies</title>
        <link rel=\"stylesheet\" href=\"/static/css/styles.css\">
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
          google.charts.load('current', {{'packages':['corechart']}});
          google.charts.setOnLoadCallback(drawChart);

          function drawChart() {{
            var data = google.visualization.arrayToDataTable([
              {chart_data}
            ]);

            var options = {{
              title: 'Comparatif des Économies par Période',
              hAxis: {{ title: 'Période', titleTextStyle: {{ color: '#333' }} }},
              vAxis: {{ title: 'Coût Total (€)', minValue: 0 }},
              chartArea: {{ width: '80%', height: '70%' }},
              colors: ['#3366CC', '#FF9900', '#109618', '#990099'],
              legend: {{ position: 'bottom' }}
            }};

            var chart = new google.visualization.LineChart(document.getElementById('comparison_chart'));
            chart.draw(data, options);
          }}

          function changeAddress() {{
            const adresse = document.getElementById('adresse').value;
            const scale = document.getElementById('scale') ? document.getElementById('scale').value : 'Mois';
            window.location.href = `/economies/comparison?adresse=${{adresse}}&scale=${{scale}}`;
          }}
        </script>
      </head>
      <body>
        {navbar} <!-- insertion de la navbar -->
        <h1 style="text-align: center;">Comparatif des Économies</h1>
        <div style="text-align: center; margin-bottom: 20px;">
          <label for="adresse">Sélectionnez une adresse:</label>
          {dropdown_adresse}
        </div>
        <div id="comparison_chart" style="width: 100%; height: 500px;"></div>
      </body>
    </html>
    """
    return HTMLResponse(content=html_content)


  

  # # -------------------------GETs --------------------------- 


# # -------------------------POSTs --------------------------- 

# POST pour rajouter une mesure
@app.post("/add_mesure")
async def add_Mesure(Mesure: Mesure):
    conn = connexion_base()
    c = conn.cursor()
    c.execute(
        'INSERT INTO Mesure (id_capteur, valeur) VALUES (?, ?)', 
        (Mesure.id_capteur, Mesure.valeur)
    )
    conn.commit()
    conn.close()
    
    return {"message": "Mmesure ajoutée"}

# POST facture 
@app.post("/add_facture")
async def add_Facture(Facture: Facture):
    conn = connexion_base()
    c = conn.cursor()
    c.execute(
        'INSERT INTO Facture (id_logement, type_Facture, montant, valeur_consommation) VALUES (?, ?, ?, ?)',
        (Facture.id_logement, Facture.type_facture, Facture.montant, Facture.valeur_consommation)
    )
    conn.commit()
    conn
    return {"message": "Facture ajoutée"}

@app.post("/add_capteur")
async def add_capteur(
    type_id: int = Form(...),  # Required field
    reference_commerciale: str = Form(...),  # Required field
    port_comm: str = Form(...),  # Required field
    id_piece: int = Form(...)  # Required field
):
    conn = connexion_base()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO Capteur (type_id, reference_commerciale, port_comm, id_piece)
        VALUES (?, ?, ?, ?)
        """,
        (type_id, reference_commerciale, port_comm, id_piece)
    )
    conn.commit()
    conn.close()
    return {"message": "Capteur ajouté avec succès"}





# source: https://open-meteo.com/
API_URL = (
    "https://api.open-meteo.com/v1/forecast?"
 "latitude=48.8534&longitude=2.3488&current_weather=true"
    "&hourly=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m" "&daily=temperature_2m_max,wind_speed_10m_max&timezone=Europe/Paris"
)


def load_navbar():
    with open("WEBSITE/navbar.html", "r", encoding="utf-8") as file:
        return file.read()


print(os.path.exists("WEBSITE/navbar.html")) 


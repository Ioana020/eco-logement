




#----------------------IOANA CACAU--------------------
#----------------------EISE4      --------------------
#----------------------IOT        --------------------

import sqlite3
import random

#ouverture et initialisation de la base de données
conn = sqlite3.connect('logement.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

    
# insertion d'une facture
c.execute("INSERT INTO Facture (id_logement, type_Facture, montant, valeur_consommation) VALUES (1, 'eau', 120.3, 34)")
c.execute("INSERT INTO Facture (id_logement, type_Facture, montant, valeur_consommation) VALUES (1, 'électricité', 1209.3, 124)")

facts = []
for i in range(4):
    facts.append((1, 'eau', round(random.uniform(0, 10000), 2), round(random.uniform(0, 1000), 2)))  
    facts.append((1, 'électricité', round(random.uniform(0, 10000), 2), round(random.uniform(0, 1000), 2)))  
c.executemany('INSERT INTO Facture (id_logement, type_Facture, montant, valeur_consommation) VALUES (?, ?, ?, ?)', facts)

# insertion de plusieurs mesures dans la table Mesure
values = []
for i in range(3):  
    values.append((1, round(random.uniform(-100, 100), 2)))  
    values.append((2, round(random.uniform(0, 100), 2)))     
    values.append((3, random.choice([0, 1])))                
    values.append((4, round(random.uniform(0, 100), 2)))    
c.executemany('INSERT INTO Mesure (id_capteur, valeur) VALUES (?, ?)', values)

#lecture des données dans la table Facture
c.execute('SELECT * FROM Facture')
factures = c.fetchall()
print("Données dans la table Facture:")
for Facture in factures:
    print(dict(Facture))

# lecture des données dans la table Mesure
c.execute('SELECT * FROM Mesure')
mesures = c.fetchall()
print("\nDonnées dans la table Mesure:")
for Mesure in mesures:
    print(dict(Mesure))
    
# fermeture
conn.commit()
conn.close()

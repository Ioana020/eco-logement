-- sqlite3 logement.db
-- .read logement.sql

----------------------IOANA CACAU--------------------
----------------------EISE4      --------------------
----------------------IOT        --------------------

-- commandes de destruction des tables
DROP TABLE IF EXISTS Facture;
DROP TABLE IF EXISTS Logement;
DROP TABLE IF EXISTS Piece;
DROP TABLE IF EXISTS Capteur;
DROP TABLE IF EXISTS TypeCapteur;
DROP TABLE IF EXISTS Mesure;
DROP TABLE IF EXISTS Adresse;
DROP TABLE IF EXISTS Ville;

-- commandes de creation des tables

CREATE TABLE Logement (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    adresse TEXT NOT NULL,
    tel TEXT NOT NULL,
    adressIP TEXT NOT NULL,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Piece (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL,
    x INTEGER NOT NULL,
    y INTEGER NOT NULL,
    z INTEGER NOT NULL,
    id_logement INTEGER NOT NULL,
    FOREIGN KEY (id_logement) REFERENCES Logement(id)
);

CREATE TABLE TypeCapteur (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL,
    unite_mesure TEXT NOT NULL,
    plage_precision TEXT
);

CREATE TABLE Capteur (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_id INTEGER NOT NULL,
    reference_commerciale TEXT NOT NULL,
    port_comm TEXT NOT NULL,
    id_piece INTEGER NOT NULL,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (type_id) REFERENCES TypeCapteur(id),
    FOREIGN KEY (id_piece) REFERENCES Piece(id)
);

CREATE TABLE Mesure (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_capteur INTEGER NOT NULL,
    valeur REAL NOT NULL,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_capteur) REFERENCES Capteur(id)
);

CREATE TABLE Facture (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_logement INTEGER NOT NULL,
    type_facture TEXT NOT NULL,
    montant FLOAT NOT NULL,
    valeur_consommation REAL NOT NULL,
    date_facture DATE NOT NULL,
    unite TEXT NOT NULL,
    FOREIGN KEY (id_logement) REFERENCES Logement(id)
);

CREATE TABLE Adresse (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero INTEGER NOT NULL,
    voie TEXT NOT NULL,
    nom_voie TEXT NOT NULL,
    code_postal INTEGER NOT NULL,
    FOREIGN KEY (code_postal) REFERENCES Ville(code_postal)
);

CREATE TABLE Ville (
    code_postal INTEGER PRIMARY KEY,
    nom TEXT NOT NULL
);

-- insertion de données

-- Ajouter plusieurs logements avec adresses uniques
INSERT INTO Logement (adresse, tel, adressIP) 
VALUES 
('20 Avenue de Ioana', '0101010101', '100.100.0.10'),
('123 Rue de Paris', '0123456789', '192.168.0.1'),
('45 Avenue Victor Hugo', '0987654321', '192.168.0.2'),
('78 Boulevard Saint-Michel', '0111223344', '192.168.0.3'),
('99 Avenue des Champs', '0223344556', '192.168.0.4');

-- Ajouter des factures pour des mois et des années spécifiques
INSERT INTO Facture (id_logement, type_facture, montant, valeur_consommation, date_facture, unite) 
VALUES
(1, 'électricité', 50.0, 150.0, '2024-01-15', 'kWh'),
(1, 'électricité', 40.0, 120.0, '2024-02-15', 'kWh'),
(1, 'électricité', 60.0, 180.0, '2024-03-15', 'kWh'),
(1, 'électricité', 200.0, 600.0, '2024-12-31', 'kWh'),
(1, 'eau', 30.0, 90.0, '2024-01-10', 'litres'),
(1, 'eau', 25.0, 75.0, '2024-02-10', 'litres'),
(1, 'eau', 100.0, 300.0, '2024-12-31', 'litres'),
(2, 'électricité', 70.0, 210.0, '2024-01-20', 'kWh'),
(2, 'électricité', 65.0, 195.0, '2024-03-20', 'kWh'),
(2, 'électricité', 250.0, 750.0, '2024-12-31', 'kWh'),
(2, 'eau', 35.0, 105.0, '2024-01-15', 'litres'),
(3, 'électricité', 80.0, 240.0, '2024-01-25', 'kWh'),
(3, 'électricité', 300.0, 900.0, '2024-12-31', 'kWh'),
(3, 'déchets', 20.0, 60.0, '2024-02-25', 'kg'),
(4, 'électricité', 90.0, 270.0, '2024-01-30', 'kWh'),
(4, 'électricité', 360.0, 1080.0, '2024-12-31', 'kWh'),
(4, 'eau', 45.0, 135.0, '2024-02-10', 'litres'),
(5, 'électricité', 100.0, 300.0, '2024-01-05', 'kWh'),
(5, 'électricité', 400.0, 1200.0, '2024-12-31', 'kWh'),
(5, 'déchets', 30.0, 90.0, '2024-03-05', 'kg'),
(1, 'déchets', 15.0, 45.0, '2024-01-15', 'kg'), -- 0 Avenue de Ioana
(1, 'déchets', 20.0, 60.0, '2024-03-15', 'kg'),
(3, 'déchets', 30.0, 90.0, '2024-03-10', 'kg'),
(4, 'déchets', 35.0, 105.0, '2024-02-25', 'kg'); -- 78 Boulevard Saint-Michel

-- Ajouter des villes
INSERT INTO Ville (code_postal, nom) VALUES 
(92140, 'Clamart'),
(94200, 'Ivry-sur-Seine'),
(75007, 'Paris'),
(93300, 'Aubervilliers');

-- Ajouter des adresses associées aux villes
INSERT INTO Adresse (numero, voie, nom_voie, code_postal) VALUES
(4, 'allée', 'des groseilliers', 92140),
(14, 'rue', 'Berthelot', 94200),
(18, 'rue', 'd Estrée', 75007),
(56, 'rue', 'Arthur Rimbaud', 93300);


-- ajouter des types de capteurs
INSERT INTO TypeCapteur (nom, unite_mesure, plage_precision) 
VALUES 
('température', '°C', '-50 to 100'),
('humidité', '%', '0 to 100'),
('consommation d électricité', 'kWh', '0 to 1000'),
('consommation d eau', 'litres', '0 to 10000'),
('déchets', 'kg', '0 to 500');

-- ajouter des pièces associées aux logements existants
INSERT INTO Piece (nom, x, y, z, id_logement) 
VALUES 
('salon', 5, 4, 3, 1),
('cuisine', 4, 3, 3, 1),
('chambre', 4, 4, 3, 2),
('salle de bain', 3, 2, 3, 2),
('bureau', 3, 4, 3, 3),
('chambre 1', 5, 4, 3, 4),
('salon', 6, 5, 3, 5);

-- ajouter des capteurs
INSERT INTO Capteur (type_id, reference_commerciale, port_comm, id_piece) 
VALUES
(1, 'tmp36', 'port1', 1), -- capteur de température dans le salon
(2, 'dht11', 'port2', 2), -- capteur d'humidité dans la cuisine
(3, 'elecmeterx200', 'port3', 3), -- capteur de consommation électrique dans la chambre
(4, 'aquaflow900', 'port4', 4), -- capteur d'eau dans la salle de bain
(5, 'wastetracker500', 'port5', 5), -- capteur de déchets dans le bureau
(1, 'tmp36', 'port6', 6), -- capteur de température dans la chambre 1
(2, 'dht22', 'port7', 7); -- capteur d'humidité dans le salon

--  capteurs
INSERT INTO Mesure (id_capteur, valeur) 
VALUES
(1, 21.5), -- mesure de température dans le salon
(2, 45.0), -- mesure d'humidité dans la cuisine
(3, 150.0), -- mesure de consommation électrique dans la chambre
(4, 300.0), -- mesure de consommation d'eau dans la salle de bain
(5, 30.0), -- mesure de déchets dans le bureau
(1, 19.0), -- mesure de température dans la chambre 1
(2, 50.0); -- mesure d'humidité dans le salon
